var stagesObj={
    stages:['Todo','Doing','Done'],
    add:function(name){
        this.stages.push(name)
    }

}
export default stagesObj